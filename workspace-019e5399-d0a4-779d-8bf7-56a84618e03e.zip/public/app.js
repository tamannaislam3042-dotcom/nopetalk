const state = {
  token: localStorage.getItem('pulsechat_token'),
  me: null,
  users: [],
  rooms: [],
  activeRoomId: null,
  messages: new Map(),
  socket: null,
  typing: new Map(),
  typingTimer: null
};

const $ = (sel) => document.querySelector(sel);
const authScreen = $('#authScreen');
const chatApp = $('#chatApp');
const toastBox = $('#toast');
const loginTab = $('#loginTab');
const registerTab = $('#registerTab');
const loginForm = $('#loginForm');
const registerForm = $('#registerForm');
const roomsList = $('#roomsList');
const usersList = $('#usersList');
const messagesEl = $('#messages');
const messageForm = $('#messageForm');
const messageInput = $('#messageInput');
const sendBtn = $('#sendBtn');
const typingLine = $('#typingLine');
const groupDialog = $('#groupDialog');

function toast(msg) {
  toastBox.textContent = msg;
  toastBox.classList.add('show');
  clearTimeout(toastBox._timer);
  toastBox._timer = setTimeout(() => toastBox.classList.remove('show'), 3000);
}

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const res = await fetch(path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function initials(name = '?') {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map(x => x[0]).join('').toUpperCase() || '?';
}

function setAvatar(el, userOrTitle) {
  const name = typeof userOrTitle === 'string' ? userOrTitle : userOrTitle.displayName;
  el.textContent = initials(name);
  if (typeof userOrTitle !== 'string' && userOrTitle.avatarColor) {
    el.style.background = userOrTitle.avatarColor;
  } else {
    el.style.background = 'linear-gradient(135deg, #1877f2, #8b5cf6)';
  }
}

function showAuth() {
  authScreen.classList.remove('hidden');
  chatApp.classList.add('hidden');
}

function showChat() {
  authScreen.classList.add('hidden');
  chatApp.classList.remove('hidden');
}

function setAuthTab(tab) {
  const login = tab === 'login';
  loginTab.classList.toggle('active', login);
  registerTab.classList.toggle('active', !login);
  loginForm.classList.toggle('hidden', !login);
  registerForm.classList.toggle('hidden', login);
}

loginTab.addEventListener('click', () => setAuthTab('login'));
registerTab.addEventListener('click', () => setAuthTab('register'));

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = Object.fromEntries(new FormData(loginForm));
  try {
    const data = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(body) });
    await acceptAuth(data);
  } catch (err) { toast(err.message); }
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = Object.fromEntries(new FormData(registerForm));
  try {
    const data = await api('/api/auth/register', { method: 'POST', body: JSON.stringify(body) });
    await acceptAuth(data);
  } catch (err) { toast(err.message); }
});

async function acceptAuth(data) {
  state.token = data.token;
  state.me = data.user;
  localStorage.setItem('pulsechat_token', state.token);
  showChat();
  connectSocket();
  await loadInitial();
}

$('#logoutBtn').addEventListener('click', () => {
  localStorage.removeItem('pulsechat_token');
  state.token = null;
  state.me = null;
  state.activeRoomId = null;
  if (state.socket) state.socket.disconnect();
  showAuth();
});

async function boot() {
  if (!state.token) return showAuth();
  try {
    const data = await api('/api/me');
    state.me = data.user;
    showChat();
    connectSocket();
    await loadInitial();
  } catch {
    localStorage.removeItem('pulsechat_token');
    showAuth();
  }
}

async function loadInitial() {
  renderMe();
  const [rooms, users] = await Promise.all([api('/api/rooms'), api('/api/users')]);
  state.rooms = rooms.rooms;
  state.users = users.users;
  renderRooms();
  renderUsers();
  renderGroupMemberList();
}

function renderMe() {
  $('#meName').textContent = state.me.displayName;
  $('#meUsername').textContent = `@${state.me.username}`;
  setAvatar($('#meAvatar'), state.me);
}

function connectSocket() {
  if (state.socket) state.socket.disconnect();
  state.socket = io({ auth: { token: state.token } });
  state.socket.on('connect_error', (err) => toast(err.message || 'Socket connection failed'));
  state.socket.on('ready', ({ rooms }) => {
    if (rooms) {
      mergeRooms(rooms);
      renderRooms();
    }
  });
  state.socket.on('presence:update', ({ userId, online }) => {
    state.users = state.users.map(u => u.id === userId ? { ...u, online } : u);
    state.rooms = state.rooms.map(room => ({ ...room, members: room.members.map(m => m.id === userId ? { ...m, online } : m) }));
    renderUsers();
    renderRooms();
    updateRoomHeader();
  });
  state.socket.on('user:update', (user) => {
    state.users = state.users.map(u => u.id === user.id ? { ...u, ...user } : u);
    state.rooms = state.rooms.map(room => ({ ...room, members: room.members.map(m => m.id === user.id ? { ...m, ...user } : m) }));
    renderUsers(); renderRooms(); updateRoomHeader();
  });
  state.socket.on('room:upsert', (room) => {
    mergeRooms([room]);
    renderRooms();
    renderGroupMemberList();
  });
  state.socket.on('message:new', (msg) => {
    const list = state.messages.get(msg.roomId) || [];
    if (!list.some(m => m.id === msg.id)) list.push(msg);
    state.messages.set(msg.roomId, list);
    const room = state.rooms.find(r => r.id === msg.roomId);
    if (room) room.lastMessage = msg;
    renderRooms();
    if (state.activeRoomId === msg.roomId) renderMessages();
  });
  state.socket.on('typing:update', ({ roomId, user, typing }) => {
    if (roomId !== state.activeRoomId || user.id === state.me.id) return;
    if (!state.typing.has(roomId)) state.typing.set(roomId, new Map());
    const map = state.typing.get(roomId);
    if (typing) map.set(user.id, user.displayName); else map.delete(user.id);
    renderTyping();
  });
}

function mergeRooms(rooms) {
  rooms.forEach(room => {
    const idx = state.rooms.findIndex(r => r.id === room.id);
    if (idx >= 0) state.rooms[idx] = { ...state.rooms[idx], ...room };
    else state.rooms.push(room);
  });
  state.rooms.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
}

function roomSubtitle(room) {
  if (!room) return '';
  if (room.type === 'dm') {
    const other = room.members.find(m => m.id !== state.me.id) || room.members[0];
    return other?.online ? 'Online now' : `@${other?.username || 'user'}`;
  }
  return `${room.members.length} members`;
}

function renderRooms() {
  if (!state.rooms.length) {
    roomsList.className = 'list empty-list';
    roomsList.textContent = 'No chats yet. Search a person to start.';
    return;
  }
  roomsList.className = 'list';
  roomsList.innerHTML = '';
  state.rooms.forEach(room => {
    const btn = document.createElement('button');
    btn.className = `list-item ${room.id === state.activeRoomId ? 'active' : ''}`;
    btn.type = 'button';
    const other = room.type === 'dm' ? room.members.find(m => m.id !== state.me.id) : null;
    btn.innerHTML = `
      <div class="avatar"></div>${other?.online ? '<span class="dot"></span>' : ''}
      <div class="item-main">
        <div class="item-top"><span class="item-name"></span><span class="item-last">${room.lastMessage ? timeShort(room.lastMessage.createdAt) : ''}</span></div>
        <div class="item-last"></div>
      </div>`;
    setAvatar(btn.querySelector('.avatar'), other || room.title || room.name);
    btn.querySelector('.item-name').textContent = room.title || room.name || 'Chat';
    btn.querySelector('.item-last:last-child').textContent = room.lastMessage ? `${room.lastMessage.senderId === state.me.id ? 'You: ' : ''}${room.lastMessage.text}` : roomSubtitle(room);
    btn.addEventListener('click', () => selectRoom(room.id));
    roomsList.appendChild(btn);
  });
}

function renderUsers() {
  const q = $('#searchInput').value.trim().toLowerCase();
  const filtered = state.users.filter(u => !q || u.displayName.toLowerCase().includes(q) || u.username.includes(q));
  if (!filtered.length) {
    usersList.className = 'list empty-list';
    usersList.textContent = 'No people found.';
    return;
  }
  usersList.className = 'list';
  usersList.innerHTML = '';
  filtered.forEach(user => {
    const btn = document.createElement('button');
    btn.className = 'list-item';
    btn.type = 'button';
    btn.innerHTML = `
      <div class="avatar"></div>${user.online ? '<span class="dot"></span>' : ''}
      <div class="item-main"><div class="item-name"></div><div class="item-last"></div></div>`;
    setAvatar(btn.querySelector('.avatar'), user);
    btn.querySelector('.item-name').textContent = user.displayName;
    btn.querySelector('.item-last').textContent = user.online ? 'Online' : `@${user.username}`;
    btn.addEventListener('click', () => startDm(user.id));
    usersList.appendChild(btn);
  });
}

$('#searchInput').addEventListener('input', debounce(async () => {
  try {
    const q = $('#searchInput').value.trim();
    const data = await api(`/api/users?q=${encodeURIComponent(q)}`);
    state.users = data.users;
    renderUsers();
    renderGroupMemberList();
  } catch (err) { toast(err.message); }
}, 200));

async function startDm(userId) {
  try {
    const data = await api('/api/rooms/dm', { method: 'POST', body: JSON.stringify({ userId }) });
    mergeRooms([data.room]);
    renderRooms();
    await selectRoom(data.room.id);
  } catch (err) { toast(err.message); }
}

async function selectRoom(roomId) {
  state.activeRoomId = roomId;
  chatApp.classList.add('chat-open');
  if (state.socket) state.socket.emit('room:join', { roomId });
  if (!state.messages.has(roomId)) {
    try {
      const data = await api(`/api/rooms/${roomId}/messages`);
      state.messages.set(roomId, data.messages);
    } catch (err) { toast(err.message); }
  }
  renderRooms();
  updateRoomHeader();
  enableComposer();
  renderMessages();
}

$('#backBtn').addEventListener('click', () => chatApp.classList.remove('chat-open'));

function updateRoomHeader() {
  const room = state.rooms.find(r => r.id === state.activeRoomId);
  if (!room) return;
  $('#roomTitle').textContent = room.title || room.name || 'Chat';
  $('#roomSubtitle').textContent = roomSubtitle(room);
  const other = room.type === 'dm' ? room.members.find(m => m.id !== state.me.id) : null;
  setAvatar($('#roomAvatar'), other || room.title || room.name);
}

function enableComposer() {
  messageForm.classList.remove('disabled');
  messageInput.disabled = false;
  sendBtn.disabled = false;
  messageInput.placeholder = 'Message...';
  messageInput.focus();
}

function renderMessages() {
  const room = state.rooms.find(r => r.id === state.activeRoomId);
  const list = state.messages.get(state.activeRoomId) || [];
  messagesEl.className = 'messages';
  messagesEl.innerHTML = '';
  if (!list.length) {
    messagesEl.classList.add('empty-state');
    messagesEl.innerHTML = `<div><div class="empty-logo">👋</div><h3>Say hello</h3><p>No messages in ${escapeHtml(room?.title || 'this chat')} yet.</p></div>`;
    return;
  }
  list.forEach(msg => messagesEl.appendChild(messageNode(msg, room)));
  requestAnimationFrame(() => { messagesEl.scrollTop = messagesEl.scrollHeight; });
}

function messageNode(msg, room) {
  const mine = msg.senderId === state.me.id;
  const row = document.createElement('div');
  row.className = `msg-row ${mine ? 'mine' : ''}`;
  const showAvatar = room?.type === 'group' && !mine;
  row.innerHTML = `
    ${showAvatar ? '<div class="avatar"></div>' : '<div style="width:30px"></div>'}
    <div>
      <div class="msg-name"></div>
      <div class="bubble"><div class="msg-text"></div><div class="msg-time"></div></div>
    </div>`;
  if (showAvatar) setAvatar(row.querySelector('.avatar'), msg.sender || { displayName: '?' });
  row.querySelector('.msg-name').textContent = msg.sender?.displayName || 'Unknown';
  row.querySelector('.msg-text').textContent = msg.text;
  row.querySelector('.msg-time').textContent = timeFull(msg.createdAt);
  return row;
}

messageForm.addEventListener('submit', (e) => {
  e.preventDefault();
  sendMessage();
});

messageInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

messageInput.addEventListener('input', () => {
  messageInput.style.height = 'auto';
  messageInput.style.height = `${messageInput.scrollHeight}px`;
  if (!state.activeRoomId || !state.socket) return;
  state.socket.emit('typing:start', { roomId: state.activeRoomId });
  clearTimeout(state.typingTimer);
  state.typingTimer = setTimeout(() => state.socket.emit('typing:stop', { roomId: state.activeRoomId }), 900);
});

function sendMessage() {
  const text = messageInput.value.trim();
  if (!text || !state.activeRoomId || !state.socket) return;
  const roomId = state.activeRoomId;
  messageInput.value = '';
  messageInput.style.height = 'auto';
  state.socket.emit('typing:stop', { roomId });
  state.socket.emit('message:send', { roomId, text }, (ack) => {
    if (!ack?.ok) toast(ack?.error || 'Message failed');
  });
}

function renderTyping() {
  const names = Array.from((state.typing.get(state.activeRoomId) || new Map()).values());
  typingLine.textContent = names.length ? `${names.join(', ')} ${names.length === 1 ? 'is' : 'are'} typing...` : '';
}

$('#newGroupBtn').addEventListener('click', () => {
  renderGroupMemberList();
  groupDialog.showModal();
});
$('#closeGroupDialog').addEventListener('click', () => groupDialog.close());
$('#cancelGroup').addEventListener('click', () => groupDialog.close());

function renderGroupMemberList() {
  const box = $('#groupMemberList');
  box.innerHTML = '';
  if (!state.users.length) {
    box.innerHTML = '<p class="muted">No users available. Invite/register another account first.</p>';
    return;
  }
  state.users.forEach(user => {
    const label = document.createElement('label');
    label.className = 'check-row';
    label.innerHTML = `<input type="checkbox" value="${user.id}"><span class="avatar"></span><span><strong></strong><br><span class="muted"></span></span>`;
    setAvatar(label.querySelector('.avatar'), user);
    label.querySelector('strong').textContent = user.displayName;
    label.querySelector('.muted').textContent = `@${user.username}${user.online ? ' • online' : ''}`;
    box.appendChild(label);
  });
}

$('#groupForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = $('#groupName').value.trim();
  const memberIds = Array.from($('#groupMemberList').querySelectorAll('input:checked')).map(i => i.value);
  try {
    const data = await api('/api/rooms/group', { method: 'POST', body: JSON.stringify({ name, memberIds }) });
    mergeRooms([data.room]);
    renderRooms();
    groupDialog.close();
    $('#groupName').value = '';
    await selectRoom(data.room.id);
  } catch (err) { toast(err.message); }
});

function timeShort(iso) {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function timeFull(iso) {
  return new Date(iso).toLocaleString([], { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' });
}
function debounce(fn, wait) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
}
function escapeHtml(s) {
  return String(s).replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
}

boot();
